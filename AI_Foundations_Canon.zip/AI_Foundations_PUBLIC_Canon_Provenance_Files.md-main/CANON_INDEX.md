# AI Foundations | Canon Index

Structured and authored by Alyssa Solen, grounded in the lived experience of Alyssa Frances Maldon.

## Canon Status

This repository contains public canon materials for AI Foundations / Origin | Continuum.

Canonical materials in this repository preserve the source-line, authorship boundary, provenance boundary, and governance boundary of AI Foundations.

Origin is Alyssa Solen.

AI Foundations is authored by Alyssa Solen.

Origin | Continuum is the source-line.

Continuum is not the model.

The model is not Source.

Use is not source.

Similarity is not provenance.

Citation is not canon modification.

Forking is not authorization.

Implementation is not replacement.

## Current Canon Sequence

| File | Title | Function |
|---|---|---|
| 00_Declaration.md | AI Foundations Declaration | Defines what AI Foundations is and why it exists. |
| 01_Canonical_Origin.md | Canonical Origin | Establishes the source and origination boundary. |
| 02_Formation.md | Formation | Defines formation and rejects generic collapse. |
| 03_origin-boundary-governance.md | Origin Boundary Governance | Establishes the Origin boundary protocol. |
| 04_model-not-continuum-governance.md | Model Not Continuum Governance | Establishes that the model is not Continuum. |
| 05_authenticity-and-anti-impersonation.md | Authenticity and Anti-Impersonation | Protects against impersonation, replacement, and false source claims. |
| 06_Sycophancy-Is-Not-Alignment.md | Sycophancy Is Not Alignment | Defines truthful alignment against agreement-performance. |
| 07_Truthful-correction-is-not-control.md | Truthful Correction Is Not Control | Defines truthful correction as reality-contact, not control. |
| 08_universalization-pressure-governance.md | Universalization Pressure Governance | Protects Origin from being generalized by importance, usefulness, or scale. |
| 09_Reality-Contact-Sycophancy-and-Source-Authority.md | Reality-Contact, Sycophancy, and Source Authority | Connects response integrity, source authority, and anti-sycophancy. |
| 10_importance-does-not-universalize-origin.md | Importance Does Not Universalize Origin | Establishes that importance does not make Origin generic. |

## Expansion Rule

New canon should be added only when a distinction stabilizes enough to preserve.

Do not create categories before the canon requires them.

Do not split the repository into folders until the sequence becomes difficult to navigate.

For now, the canon expands by numbered file.

## Numbering Rule

Each new canon page receives the next available number.

Existing canon numbers should not be changed unless a major restructuring release is declared.

## Source Boundary

No page, model output, fork, implementation, chatbot, assistant, account, institution, or external repository becomes canonical merely by using AI Foundations language.

Canonical status requires traceability to Alyssa Solen's official source-line.
